create definer = root@localhost trigger update_status_after_update_registro_causal
    before update
    on registro_causal
    for each row
BEGIN

    UPDATE status
    SET Causal = NEW.Causal,
        Code = NEW.Code,
        date = NEW.data,
        time = NEW.hora_inicio
    WHERE testCell = NEW.testCell;

END;

