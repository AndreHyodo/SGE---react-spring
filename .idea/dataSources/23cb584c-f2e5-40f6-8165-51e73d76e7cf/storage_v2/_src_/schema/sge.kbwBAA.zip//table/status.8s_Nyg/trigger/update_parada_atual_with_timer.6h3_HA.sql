create definer = root@localhost trigger update_parada_atual_with_timer
    after update
    on status
    for each row
BEGIN
    DECLARE update_time TIMESTAMP;
    DECLARE last_status_change TIMESTAMP;
    DECLARE time_elapsed INT;

    -- Get the current timestamp
    SET update_time = CURRENT_TIMESTAMP();

    -- Get the timestamp of the last status change
    SELECT parada_atual
    INTO last_status_change
    FROM status
    WHERE id = NEW.id;

    -- Calculate time elapsed since last status change
    IF last_status_change IS NOT NULL THEN
        SET time_elapsed = UNIX_TIMESTAMP(update_time) - UNIX_TIMESTAMP(last_status_change);
    ELSE
        SET time_elapsed = 0;
    END IF;

    -- Update 'parada_atual' with the calculated time elapsed
    IF NEW.Status != OLD.Status THEN
        UPDATE timers_paradas
        SET parada_atual = time_elapsed
        WHERE id = NEW.id;
    END IF;
END;

